==============
Shaphinx - 一个 Sphinx 主题
==============


.. image:: https://img.shields.io/pypi/v/shaphinx.svg
        :target: https://pypi.python.org/pypi/shaphinx

.. image:: https://img.shields.io/travis/llango/shaphinx.svg
        :target: https://travis-ci.com/llango/shaphinx

.. image:: https://readthedocs.org/projects/shaphinx/badge/?version=latest
        :target: https://shaphinx.readthedocs.io/en/latest/?version=latest
        :alt: Documentation Status




该主题是我用于火葱科技文档编写的主题，绝对不错，特意开源分享出来。你可以试试。


* 免费软件: MIT license
* 文档: https://shaphinx.readthedocs.io.

特征
--------

* 主题比较清新，参考gitbook等主题。

名单
-------

该包使用 Cookiecutter_ 和 `audreyr/cookiecutter-pypackage`_ 项目模板创建.

.. _Cookiecutter: https://github.com/audreyr/cookiecutter
.. _`audreyr/cookiecutter-pypackage`: https://github.com/audreyr/cookiecutter-pypackage
