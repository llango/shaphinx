=====
Usage
=====

To use A Sphinx Theme in a project::

    import shaphinx
